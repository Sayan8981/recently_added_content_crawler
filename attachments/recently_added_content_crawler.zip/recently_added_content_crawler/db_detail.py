username='root'
passwd="root@123"
IP_addr='localhost'
database_name='recently_added_content_service_wise'