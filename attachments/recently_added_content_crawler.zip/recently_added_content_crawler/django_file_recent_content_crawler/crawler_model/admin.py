# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django import *
from django.contrib import admin
from crawler_model.models import recent_content

admin.site.register(recent_content)

# Register your models here.
