# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class CrawlerModelConfig(AppConfig):
    name = 'crawler_model'
